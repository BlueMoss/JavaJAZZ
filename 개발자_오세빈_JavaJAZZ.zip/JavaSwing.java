// package sec02;

import javax.swing.JFrame;

public class JavaSwing {
    public static void main(String[] args) {
        JFrame f = new JFrame();

        f.setTitle("오세빈! ");
        f.setSize(1000, 600);
        f.setVisible(true);
    }
}