//package com.wato.javaFX;

import java.applet.Applet;
import java.awt.Graphics;

public class HelloApplet extends Applet {

    public void paint(Graphics g) {

        g.drawString("My Java Applet !!!", 1000, 1000);

    }

}